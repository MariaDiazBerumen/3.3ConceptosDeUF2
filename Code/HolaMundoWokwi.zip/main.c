//Hola mundo en Wokwi
//Maria de los Angeles Diaz Berumen 
//04 de octubre del 2023
//Notar las diferencias en emulador en linea con el IDE arduino

#include <stdio.h>
#include "pico/stdlib.h"

int main() {
  stdio_init_all();
  while (true) {
    printf("Hola,mundo\n");
    sleep_ms(250);
  }
}